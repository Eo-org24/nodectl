"""Cache package scaffold."""

