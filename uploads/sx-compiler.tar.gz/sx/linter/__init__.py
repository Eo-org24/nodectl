"""Linter package scaffold."""

