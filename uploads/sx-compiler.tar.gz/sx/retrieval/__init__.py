"""Retrieval package scaffold."""

